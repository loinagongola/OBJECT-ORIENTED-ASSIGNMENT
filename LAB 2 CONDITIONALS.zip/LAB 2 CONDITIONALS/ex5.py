# multiples

a = int(input("enter value of a: "))
b = int(input("enter value of b: "))

if (a % b) == 0:
    print(a / b)
else:
    print("a is not a multiple of b")
    
    

    
    

