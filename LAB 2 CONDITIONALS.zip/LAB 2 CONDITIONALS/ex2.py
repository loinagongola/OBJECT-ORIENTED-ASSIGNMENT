# integer comparison

a=int(input("enter value of a: "))
b=int(input("enter value of b: "))

if a > b:
    print("a is greater than b")    
elif a < b:
    print("a is less than b")    
else:
    print("a is equal b")
    
    
    
    