# area of a trapezoid

a= float(input("enter the value of a = "))
b= float(input("enter the value of b = "))
h= float(input("enter the value of h = "))


area = ((a + b)/2)*h


print(((a + b)/2)*h)

