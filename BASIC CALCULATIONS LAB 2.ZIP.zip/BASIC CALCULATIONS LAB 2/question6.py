# volume of a cube

l=float(input("enter the value of l: "))

volume = (l* l *l)

print(volume)
