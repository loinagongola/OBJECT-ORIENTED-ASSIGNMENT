# area and circumference of a circle

pi=22/7

r= float(input("enter the radius of the circle: "))

Area= (pi * (r * r))

Circumference=((2*r) * pi)

C= ("Circumference: " + str(Circumference))

A= ("Area: " + str(Area))


print(A)
print(C)



