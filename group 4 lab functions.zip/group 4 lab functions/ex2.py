def area_of_a_rectangle(b, c):
    area = b * c
    print(area)
    
area_of_a_rectangle(2, 3)
